from django import template
from django.contrib.humanize.templatetags.humanize import intcomma

register = template.Library()

@register.filter
def currency_vnd(value):
    """
    Định dạng số tiền VND với dấu phẩy phân cách hàng nghìn
    Ví dụ: 25000000 -> 25,000,000 VNĐ
    """
    if value is None or value == '':
        return '0 VNĐ'

    try:
        value = int(float(value))
        formatted = intcomma(value)
        return f"{formatted} VNĐ"
    except (ValueError, TypeError):
        return '0 VNĐ'

@register.filter
def currency_only(value):
    """
    Chỉ định dạng số với dấu phẩy, không có đơn vị VNĐ
    Ví dụ: 25000000 -> 25,000,000
    """
    if value is None or value == '':
        return '0'

    try:
        value = int(float(value))
        return intcomma(value)
    except (ValueError, TypeError):
        return '0'
