from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import ChiTietBangLuong, Luong

@receiver(post_save, sender=ChiTietBangLuong)
def sync_luong_from_chitiet(sender, instance, created, **kwargs):
    """
    Đảm bảo mức Lương Cơ Bản, BHXH, Phụ cấp và Thuế TNCN mới nhất
    được đồng bộ sang bảng Luong (Thông tin Lương cơ bản).
    """

    nv_instance = instance.manhanvien

    latest_chitiet = ChiTietBangLuong.objects.filter(manhanvien=nv_instance).order_by('-thang_luong').first()

    if latest_chitiet and latest_chitiet.thang_luong > instance.thang_luong:
         return

    tong_phu_cap = instance.phu_cap_antrua + instance.phu_cap_xang_xe + instance.phu_cap_khac

    luong_instance, created_luong = Luong.objects.update_or_create(
        manhanvien=nv_instance,
        defaults={
            'luong_hop_dong': instance.luong_co_ban_thuc_lanh,
            'hesoluong': 1.0,
            'phucap_antrua': instance.phu_cap_antrua,
            'phucap_xangxe': instance.phu_cap_xang_xe,
            'phucap_khac': instance.phu_cap_khac,
        }
    )
