from django.contrib import admin
from .models import *

admin.site.register(PhongBan)
admin.site.register(ChucVu)
admin.site.register(HopDong)
admin.site.register(NhanVien)
admin.site.register(Luong)
admin.site.register(ChiTietBangLuong)
admin.site.register(KhenThuongKyLuat)
admin.site.register(TaiKhoan)
admin.site.register(NghiPhep)
admin.site.register(LichSuChuyenKhoan)
